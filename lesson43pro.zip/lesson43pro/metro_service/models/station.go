package models

type Station struct {
	Id, Name string
}

type CreateStation struct {
	Name string
}
