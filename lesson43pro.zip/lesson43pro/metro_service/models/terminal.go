package models

type Terminal struct{
	Id string
	StationId string
}