package models

type Card struct {
	Id     string
	Number string
	UserId string
}
