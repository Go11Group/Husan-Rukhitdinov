package models

type Transaction struct {
	Id         string
	CardID     string
	Amount     string
	TerminalId string
}
