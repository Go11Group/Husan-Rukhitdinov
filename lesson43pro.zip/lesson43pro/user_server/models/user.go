package models

type User struct {
	Id        string
	Name      string
	Phone     string
	Age       int
	CreatedAt string
	UpdatedAt string
	DeletedAt string
}
